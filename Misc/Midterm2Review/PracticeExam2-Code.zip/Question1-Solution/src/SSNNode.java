// ListNode.java

public class SSNNode
{
   public String data;
   public SSNNode next;

   public SSNNode(String d)
   {
      data = d;
      next = null;
   }  // constructor
}  // class ShortNode

