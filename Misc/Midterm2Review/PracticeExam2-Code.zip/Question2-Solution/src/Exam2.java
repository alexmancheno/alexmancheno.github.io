
public interface Exam2 {
	public int getAnswer(int i, int j);
	public String getString(String[] s, int i);
}
