
public class Exam2Super {
	public int getAnswer(int p, int q) {
		return p+q;
	}
}
