// 2.a solution

public class Exam2class implements Exam2 {

	public String getString(String[] s, int i) {
		return null;
	}

	public int getAnswer(int i, int j) {
		return i + j;
	}

}

// 2.b solution (comment out the first solution and uncomment this one to see that it works)


//public class Exam2class extends Exam2Super implements Exam2 {
//
//	public String getString(String[] s, int i) {
//		return null;
//	}
//
//
//}
