// Question 3.c
public class FlyingAnimalException extends IllegalArgumentException {
	public FlyingAnimalException(String msg) {
		super(msg);
	}
}
