
public class InvalidAnimalException extends IllegalArgumentException {
	public InvalidAnimalException(String msg) {
		super(msg);
	}
}
