
public class Question4 {
	public static void main(String[] args) {
		Bat igor = null;
		Bird robin;
		FlyingAnimal finch;
		
		// Uncomment each one, one at a time to see output
		
		// 4.a
		
		igor = new Bat("Vampire", 1200, 30);
		
		// 4.b
		
//		igor = new Bat(null, 1200, 30, false);
		
		// 4.c
		
//		robin = new Bird("Robin", 3000, 50, true);
		
		// 4.d
		
//		robin = new Bird("Robin");
		
		// 4.e
		
//		igor = new Bat("", 20, 25);
		
		// 4.f
		
//		finch = new FlyingAnimal("Finch", 5000, 45);
	}
}
