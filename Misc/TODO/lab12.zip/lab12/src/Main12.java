import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;

import java.awt.GridLayout;

import javax.swing.JTextArea;
import javax.swing.JFrame;

public class Main12
{
    public static void main(String[] args)
    {
        // TODO
    }
}


// Create a custom gui class
class Gui12 extends JFrame
{
    // Instance variables
    private JTextArea leftTextArea;
    private JTextArea rightTextArea;
    private StringBuilder oddStringBuilder;
    private StringBuilder evenStringBuilder;

    // Default constructor
    public Gui12()
    {
        // TODO
    }

    // Constructor with a string as a parameter. Instantiate all the instance
    // variables and configure the JFrame here
    public Gui12(String title)
    {
        // TODO
    }

    // Make the gui visible
    public void showGui()
    {
        // TODO
    }

    // Print even numbers on the left side and odd numbers on the right side
    public void displayEvenAndOddNumbers(String file)
    {
        // TODO
    }
}