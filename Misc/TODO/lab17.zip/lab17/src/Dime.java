class Dime extends Money 
{
    public Dime() 
    {
        super(10);
    }

    @Override
    public String toString() 
    {
        return "dime object";
    }
}