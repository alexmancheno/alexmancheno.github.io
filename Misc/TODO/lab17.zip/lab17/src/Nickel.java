class Nickel extends Money 
{
    public Nickel() 
    {
        super(5);
    }

    @Override
    public String toString() 
    {
        return "nickel object";
    }
}