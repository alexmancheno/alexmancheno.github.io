class Penny extends Money 
{
    public Penny() 
    {
        super(1);
    }

    @Override
    public String toString() 
    {
        return "penny object";
    }
}