class Quarter extends Money 
{
    public Quarter() 
    {
        super(25);
    }

    @Override
    public String toString() 
    {
        return "quarter object";
    }
}