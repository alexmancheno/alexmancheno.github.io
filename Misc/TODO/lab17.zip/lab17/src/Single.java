class Single extends Money 
{
    public Single() 
    {
        super(100);
    }

    @Override
    public String toString() 
    {
        return "single object";
    }
}