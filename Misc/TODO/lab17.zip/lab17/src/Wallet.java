class Wallet 
{
    // TODO - Instance variables

    // Default constructor
    public Wallet() 
    {
        // TODO
    }

    public void add(Money money) 
    {
        // TODO
    }

    // Print the contents inside the wallet
    public void printContent() 
    {
        // TODO
    }

    // Print a string in the format of: $13.32
    @Override
    public String toString() 
    {
        // TODO
    }
}