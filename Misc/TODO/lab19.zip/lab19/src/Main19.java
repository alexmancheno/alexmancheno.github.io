public class Main19
{
    public static void main(String[] args)
    {
        Lab19Gui gui = new Lab19Gui("Lab 19");
        gui.displayGui();
    }
}